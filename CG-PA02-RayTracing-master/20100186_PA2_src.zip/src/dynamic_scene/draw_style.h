#ifndef CGL_DYNAMICSCENE_DRAWSTYLE_H
#define CGL_DYNAMICSCENE_DRAWSTYLE_H

#include "scene.h"

namespace CGL { namespace DynamicScene {

/**
 * Used in rendering to specify how to draw the faces/meshes/lines/etc.
 */
class DrawStyle {
 public:

  void style_reset() const {
    glLineWidth(1);
    glPointSize(1);
  }

  void style_face() const {
    glColor4fv(&faceColor.r);
  }

  void style_edge() const {
    glColor4fv(&edgeColor.r);
    glLineWidth(strokeWidth);
  }

  void style_halfedge() const {
    glColor4fv(&halfedgeColor.r);
    glLineWidth(strokeWidth);
  }

  void style_vertex() const {
    glColor4fv(&vertexColor.r);
    glPointSize(vertexRadius);
  }

  Color halfedgeColor;
  Color vertexColor;
  Color edgeColor;
  Color faceColor;

  float strokeWidth;
  float vertexRadius;
};

} // namespace DynamicScene
} // namespace CGL

#endif //CGL_DYNAMICSCENE_DRAWSTYLE_H
